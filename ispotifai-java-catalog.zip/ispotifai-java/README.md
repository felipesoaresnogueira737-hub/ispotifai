# iSpotifai (JavaFX)

Player de música em tema roxo. Toca os arquivos de áudio (mp3, wav, m4a, aac, aif) que você adiciona.

## Rodar no computador
```
mvn javafx:run
```
(Java 17+ e Maven). Para ver o layout de celular no PC: `mvn javafx:run -Djavafx.args= -Dmobile=true`.

## Gerar o APK pelo GitHub
1. Crie um repositório no GitHub e envie **todos** estes arquivos (inclusive a pasta `.github`).
2. Abra a aba **Actions** > **Gerar APK (Android)** > **Run workflow**.
3. Espere terminar (de 20 a 60 minutos na primeira vez).
4. Na página da execução, baixe o artefato **ispotifai-apk**, instale o `.apk` no celular (permita "fontes desconhecidas").
5. Se falhar, baixe o artefato **logs-de-erro** e me mande o texto do erro.

## No Android
- Não há seletor de arquivos: o botão "Adicionar músicas" lê a pasta **Música** do celular. Coloque lá seus áudios.
- Você precisa dar permissão de acesso ao armazenamento/áudio ao app.


## Catálogo próprio e downloads offline

O app agora tem as áreas **Catálogo** e **Músicas baixadas**. O catálogo é carregado de uma URL HTTPS que retorna JSON. Os arquivos de áudio também precisam estar disponíveis por HTTPS, sem login/cookies necessários para o download.

### Formato do catálogo

Veja `catalog.example.json`. O endpoint pode retornar um objeto com a propriedade `tracks` (lista) ou diretamente uma lista de faixas. Cada faixa usa:

- `id`: identificador estável e único;
- `title` e `artist`: textos exibidos no app;
- `audioUrl`: URL HTTPS direta do arquivo de áudio;
- `downloadable`: `true` somente quando o download foi autorizado;
- `license`: texto que identifica a autorização/licença;
- `durationSeconds`: duração opcional em segundos.

Hospede o JSON e os áudios num servidor que você controla ou tem autorização para usar. Depois abra **Biblioteca > Catálogo > Configurar servidor** e informe a URL HTTPS do JSON. O app baixa apenas faixas marcadas com `downloadable: true` e `license` preenchido. Não inclua músicas sem autorização para redistribuição.

### Armazenamento

Os downloads e o índice da biblioteca ficam no armazenamento privado do app no Android e em `~/.ispotifai/downloads` no computador. A lista de downloads persiste ao fechar e abrir o app. Remover um download apaga o arquivo local e remove essa faixa da biblioteca do app.

### Observações

- O catálogo requer internet; as faixas baixadas tocam localmente sem conexão.
- Use IDs únicos e estáveis. Alterar o ID de uma faixa faz o app tratá-la como outra música.
- O exemplo contém URLs fictícias: substitua-as pelas URLs HTTPS reais do seu servidor antes de testar.
- Este projeto não inclui um servidor de músicas. Você precisa hospedar o JSON e os arquivos de áudio separadamente.
