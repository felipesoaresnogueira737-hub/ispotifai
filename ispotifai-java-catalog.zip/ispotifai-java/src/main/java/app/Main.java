package app;

import com.gluonhq.attach.storage.StorageService;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.geometry.VPos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/** iSpotifai: player de música (tema roxo). Toca os arquivos de áudio que o usuário adiciona. */
public class Main extends Application {

    // ---------- ícones (viewBox 24x24) ----------
    static final String HOME = "M12.5 3.2a1 1 0 0 0-1 0L3 8.5V21h6.5v-6.5h5V21H21V8.5z";
    static final String SEARCH = "M10.5 3a7.5 7.5 0 1 0 4.6 13.4l4.8 4.8 1.4-1.4-4.8-4.8A7.5 7.5 0 0 0 10.5 3zm0 2a5.5 5.5 0 1 1 0 11 5.5 5.5 0 0 1 0-11z";
    static final String LIB = "M4 3h2v18H4zm5 0h2v18H9zm5.5.5l1.9-.6 5.1 17.4-1.9.6z";
    static final String PLUS = "M11 4h2v7h7v2h-7v7h-2v-7H4v-2h7z";
    static final String PLAY = "M7 4v16l14-8z";
    static final String PAUSE = "M6 4h4v16H6zm8 0h4v16h-4z";
    static final String PREV = "M6 4h2v16H6zm3 8l11-8v16z";
    static final String NEXT = "M16 4h2v16h-2zM4 4l11 8L4 20z";
    static final String SHUF = "M16 3h5v5l-2-2-4.6 4.6-1.4-1.4L17.6 5zM3 6h4l9 12h3v-2l2 3-2 3v-2h-4L7 8H3zm0 10h4l2-2.5 1.4 1.4L8 18H3z";
    static final String REP = "M7 7h10v3l4-4-4-4v3H5v6h2zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2z";
    static final String VOL = "M3 9v6h4l5 4V5L7 9zm13.5 3a4.5 4.5 0 0 0-2.5-4v8a4.5 4.5 0 0 0 2.5-4z";
    static final String MUTE = "M3 9v6h4l5 4V5L7 9zm13 .6l1.4-1.4 2.1 2.1 2.1-2.1 1.4 1.4-2.1 2.1 2.1 2.1-1.4 1.4-2.1-2.1-2.1 2.1-1.4-1.4 2.1-2.1z";
    static final String NOTE = "M12 3v10.55A4 4 0 1 0 14 17V7h4V3z";
    static final String BELL = "M12 22a2 2 0 0 0 2-2h-4a2 2 0 0 0 2 2zm6-6V11a6 6 0 0 0-5-5.9V4a1 1 0 0 0-2 0v1.1A6 6 0 0 0 6 11v5l-2 2v1h16v-1z";
    static final String DL = "M12 16l-5-5 1.4-1.4 2.6 2.6V3h2v9.2l2.6-2.6L17 11zM5 19h14v2H5z";
    static final String FR = "M16 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM8 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm0 2c-2.3 0-7 1.2-7 3.5V19h14v-2.5C15 14.2 10.3 13 8 13zm8 0c-.3 0-.6 0-1 .1 1.2.8 2 1.9 2 3.4V19h6v-2.5c0-2.3-4.7-3.5-7-3.5z";
    static final String NPV = "M3 4h18v12H3zm2 2v8h14V6zm4 12h6v2H9z";
    static final String MIC = "M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.9V21h2v-3.1A7 7 0 0 0 19 11z";
    static final String QUEUE = "M3 6h13v2H3zm0 5h13v2H3zm0 5h8v2H3zm13 0l5 3-5 3z";
    static final String DEV = "M3 5h18v11H3zm2 2v7h14V7zm-3 11h20v2H2z";
    static final String FS = "M3 3h6v2H5v4H3zm12 0h6v6h-2V5h-4zM3 15h2v4h4v2H3zm16 0h2v6h-6v-2h4z";
    static final String DOTS = "M5 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z";
    static final String XX = "M5.7 4.3L12 10.6l6.3-6.3 1.4 1.4-6.3 6.3 6.3 6.3-1.4 1.4-6.3-6.3-6.3 6.3-1.4-1.4 6.3-6.3-6.3-6.3z";
    static final String MENU = "M3 6h18v2H3zm0 5h18v2H3zm0 5h18v2H3z";
    static final String ARROW = "M4 11h13.2l-5.6-5.6L13 4l8 8-8 8-1.4-1.4 5.6-5.6H4z";
    static final String BROWSE = "M4 4h7v7H4zm2 2v3h3V6zm7-2h7v7h-7zm2 2v3h3V6zM4 13h7v7H4zm2 2v3h3v-3zm7-2h7v7h-7zm2 2v3h3v-3z";
    static final String CLOCK = "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16zm-1 3h2v5.4l3.3 2-1 1.7L11 13z";
    static final String PIN = "M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2z";
    static final String HEART = "M12 20.5l-1.2-1.1C5.9 15 3 12.4 3 9.1 3 6.5 5 4.5 7.6 4.5c1.5 0 2.9.7 3.8 1.8h1.2c.9-1.1 2.3-1.8 3.8-1.8C19 4.5 21 6.5 21 9.1c0 3.3-2.9 5.9-7.8 10.3z";
    static final String PURPLE = "#a855f7";
    /** true no Android (ou com -Dmobile=true para testar no PC): usa layout de celular. */
    static final boolean MOBILE = "android".equalsIgnoreCase(System.getProperty("javafx.platform"))
            || System.getProperty("os.name", "").toLowerCase().contains("android") || Boolean.getBoolean("mobile");

    static final String[] CATS = {"Podcasts", "Shows ao vivo", "Feito para você", "Lançamentos", "Pop", "Sertanejo", "Funk", "Hip-Hop",
            "Rock", "MPB", "Pagode", "Eletrônica", "Treino", "Relaxamento", "Foco", "Festa"};
    static final String[] CAT_COLORS = {"#dc148c", "#4c1d95", "#8400e7", "#1e3264", "#e8115b", "#477d95", "#e13300", "#7c3aed",
            "#ba5d07", "#503750", "#af2896", "#0d73ec", "#e61e32", "#8d67ab", "#6d28d9", "#509bf5"};

    // ---------- modelo ----------
    static class Song {
        int id; String title, artist, uri; double dur; long added = System.currentTimeMillis();
    }
    static class Pl {
        String name; List<Song> songs = new ArrayList<>();
        Pl(String n) { name = n; }
    }
    static class CatalogTrack {
        String id, title, artist, audioUrl, license;
        boolean downloadable;
        double durationSeconds;
    }
    enum V { HOME, SEARCH, LIB, PL, CATALOG, DOWNLOADS }

    final List<Song> songs = new ArrayList<>();
    final List<Pl> pls = new ArrayList<>();
    final Pl liked = new Pl("Músicas Curtidas");
    final List<MediaPlayer> probes = new ArrayList<>();
    final List<CatalogTrack> catalogTracks = new ArrayList<>();
    final Map<String, File> downloadedFiles = new LinkedHashMap<>();
    final Map<String, CatalogTrack> downloadedTracks = new LinkedHashMap<>();
    File appDir, downloadsDir, catalogSettingsFile;
    String catalogUrl = "";
    boolean catalogLoading = false;
    final Random rnd = new Random();
    V view = V.HOME;
    Pl arg;
    String query = "";
    boolean libSongs, shuffle, seekDrag, rpOpen;
    int repeat, nid = 1;
    String rpMode = "np";
    Song cur;
    List<Song> queue = new ArrayList<>();
    MediaPlayer mp;
    double lastVol = .7;

    // ---------- UI ----------
    Stage stage;
    String css;
    ScrollPane mainScroll;
    VBox libList, rp;
    Button chipPl, chipSg, ppBtn, heartBtn, shufBtn, repBtn, npvBtn, qbBtn, muteBtn;
    Region ppIcon;
    Label curL = lbl("0:00", 12, false, "#b3b3b3"), durL = lbl("0:00", 12, false, "#b3b3b3");
    Label npTitle = lbl("", 14, false, "white"), npArtist = lbl("", 12, false, "#b3b3b3");
    StackPane npCover, heartHolder = new StackPane();
    Slider seek = new Slider(0, 1, 0), vol = new Slider(0, 1, .7);
    TextField searchF;
    Label toastL = new Label();
    HBox npBox;
    PauseTransition toastT = new PauseTransition(Duration.seconds(2.2));

    // ---------- helpers ----------
    static Label lbl(String t, int sz, boolean b, String col) {
        Label l = new Label(t);
        l.setStyle("-fx-font-size:" + sz + "px;-fx-font-weight:" + (b ? "bold" : "normal") + ";-fx-text-fill:" + col + ";");
        return l;
    }
    static Region icc(String path, double s, String color) {
        Region r = new Region();
        r.setStyle("-fx-shape:\"" + path + "\";-fx-background-color:" + color + ";");
        r.setMinSize(s, s); r.setPrefSize(s, s); r.setMaxSize(s, s);
        return r;
    }
    static Region ic(String path, double s) {
        Region r = new Region();
        r.getStyleClass().add("ic");
        r.setStyle("-fx-shape:\"" + path + "\";");
        r.setMinSize(s, s); r.setPrefSize(s, s); r.setMaxSize(s, s);
        return r;
    }
    static Button ib(String path, double s, Runnable r) {
        Button b = new Button();
        b.setGraphic(ic(path, s));
        b.getStyleClass().add("ib");
        b.setFocusTraversable(false);
        b.setOnAction(e -> r.run());
        return b;
    }
    static Button pill(String t, boolean outline, Runnable r) {
        Button b = new Button(t);
        b.getStyleClass().add(outline ? "pill-o" : "pill");
        b.setFocusTraversable(false);
        b.setOnAction(e -> r.run());
        return b;
    }
    static Button goBtn(double s, Runnable r) {
        Button b = new Button();
        b.setGraphic(ic(PLAY, s * .45));
        b.getStyleClass().add("go");
        b.setMinSize(s, s); b.setPrefSize(s, s); b.setMaxSize(s, s);
        b.setFocusTraversable(false);
        b.setOnAction(e -> r.run());
        return stop(b);
    }
    static <T extends Node> T stop(T n) {
        n.addEventFilter(MouseEvent.MOUSE_CLICKED, MouseEvent::consume);
        return n;
    }
    static void on(Node n, boolean b) {
        n.getStyleClass().remove("on");
        if (b) n.getStyleClass().add("on");
    }
    static StackPane cover(double s, boolean lk) {
        StackPane p = new StackPane(lk ? icc(HEART, s * .4, "white") : icc(NOTE, s * .4, "#7f7f7f"));
        p.setMinSize(s, s); p.setPrefSize(s, s); p.setMaxSize(s, s);
        p.getStyleClass().add(lk ? "cover-lk" : "cover");
        return p;
    }
    static Node heart(boolean on, double s) {
        SVGPath h = new SVGPath();
        h.setContent(HEART);
        h.setScaleX(s / 24); h.setScaleY(s / 24);
        if (on) { h.setFill(Color.web(PURPLE)); } else { h.setFill(Color.TRANSPARENT); h.setStroke(Color.web("#b3b3b3")); h.setStrokeWidth(2); }
        StackPane sp = new StackPane(new Group(h));
        sp.setMinSize(s, s); sp.setPrefSize(s, s); sp.setMaxSize(s, s);
        return sp;
    }
    static String fmt(double s) {
        if (Double.isNaN(s) || s <= 0) return "0:00";
        int t = (int) s;
        return (t / 60) + ":" + String.format("%02d", t % 60);
    }
    static Region spacer() {
        Region r = new Region();
        HBox.setHgrow(r, Priority.ALWAYS);
        return r;
    }
    void toast(String m) {
        toastL.setText(m);
        toastL.setVisible(true);
        toastT.playFromStart();
    }
    void fill(Slider s) {
        Runnable u = () -> {
            Node t = s.lookup(".track");
            if (t != null) {
                double p = (s.getValue() - s.getMin()) / (s.getMax() - s.getMin()) * 100;
                t.setStyle("-fx-background-color:linear-gradient(to right,white " + p + "%,#4d4d4d " + p + "%);");
            }
        };
        s.valueProperty().addListener((o, a, b) -> u.run());
        s.maxProperty().addListener((o, a, b) -> u.run());
        s.skinProperty().addListener((o, a, b) -> Platform.runLater(u));
    }
    void ask(String title, String def, Consumer<String> cb) {
        TextInputDialog d = new TextInputDialog(def);
        d.setTitle(title); d.setHeaderText(title); d.setContentText("Nome:");
        d.getDialogPane().getStylesheets().add(css);
        d.initOwner(stage);
        d.showAndWait().map(String::trim).filter(x -> !x.isEmpty()).ifPresent(cb);
    }

    // ---------- catálogo remoto e downloads offline ----------
    void initDownloadStorage() {
        try {
            File base = null;
            try {
                Optional<StorageService> st = StorageService.create();
                if (st.isPresent()) base = st.get().getPrivateStorage().orElse(null);
            } catch (Throwable ignored) { }
            if (base == null) base = new File(System.getProperty("user.home", "."), ".ispotifai");
            appDir = base;
            downloadsDir = new File(appDir, "downloads");
            if (!downloadsDir.exists()) downloadsDir.mkdirs();
            catalogSettingsFile = new File(appDir, "catalog.properties");
            Properties cfg = new Properties();
            if (catalogSettingsFile.isFile()) try (InputStream in = Files.newInputStream(catalogSettingsFile.toPath())) { cfg.load(in); }
            catalogUrl = cfg.getProperty("catalogUrl", "").trim();
            File index = new File(appDir, "downloads.properties");
            Properties saved = new Properties();
            if (index.isFile()) try (InputStream in = Files.newInputStream(index.toPath())) { saved.load(in); }
            for (String savedKey : saved.stringPropertyNames()) {
                if (!savedKey.startsWith("track.") || !savedKey.endsWith(".file")) continue;
                String id = savedKey.substring("track.".length(), savedKey.length() - ".file".length());
                String baseKey = "track." + id + ".";
                String fileName = saved.getProperty(baseKey + "file", "");
                File audio = new File(downloadsDir, fileName);
                if (!audio.isFile() || !audio.getCanonicalPath().startsWith(downloadsDir.getCanonicalPath())) continue;
                CatalogTrack t = new CatalogTrack();
                t.id = id; t.title = saved.getProperty(baseKey + "title", "Música baixada");
                t.artist = saved.getProperty(baseKey + "artist", "Artista desconhecido");
                t.license = saved.getProperty(baseKey + "license", "Download autorizado");
                t.downloadable = true;
                downloadedFiles.put(id, audio); downloadedTracks.put(id, t);
                Song song = new Song(); song.id = nid++; song.title = t.title; song.artist = t.artist;
                song.uri = audio.toURI().toString(); song.dur = Double.parseDouble(saved.getProperty(baseKey + "duration", "0"));
                songs.add(song);
            }
        } catch (Exception ex) { System.err.println("Não foi possível carregar downloads: " + ex.getMessage()); }
    }

    void saveCatalogUrl() {
        try {
            if (!appDir.exists()) appDir.mkdirs();
            Properties p = new Properties(); p.setProperty("catalogUrl", catalogUrl);
            try (OutputStream out = Files.newOutputStream(catalogSettingsFile.toPath())) { p.store(out, "Configuração do catálogo do iSpotifai"); }
        } catch (Exception ex) { toast("Não foi possível salvar a URL do catálogo"); }
    }

    void configureCatalog() {
        TextInputDialog d = new TextInputDialog(catalogUrl);
        d.setTitle("Catálogo do iSpotifai");
        d.setHeaderText("Conectar ao seu servidor de músicas");
        d.setContentText("URL HTTPS do catálogo JSON:");
        d.getDialogPane().getStylesheets().add(css); d.initOwner(stage);
        d.showAndWait().map(String::trim).ifPresent(value -> {
            if (!value.isEmpty() && !value.matches("^https://.+")) { toast("Use uma URL HTTPS segura"); return; }
            catalogUrl = value; saveCatalogUrl();
            if (catalogUrl.isBlank()) { catalogTracks.clear(); go(V.CATALOG); toast("Catálogo desconectado"); }
            else loadCatalog();
        });
    }

    void loadCatalog() {
        if (catalogUrl == null || catalogUrl.isBlank()) { configureCatalog(); return; }
        if (!catalogUrl.startsWith("https://")) { toast("O catálogo precisa usar HTTPS"); return; }
        catalogLoading = true; go(V.CATALOG); toast("Carregando catálogo...");
        CompletableFuture.supplyAsync(() -> {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(catalogUrl).openConnection();
                conn.setConnectTimeout(12000); conn.setReadTimeout(20000); conn.setRequestProperty("Accept", "application/json");
                conn.setInstanceFollowRedirects(false);
                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) throw new IllegalStateException("Servidor respondeu HTTP " + code);
                try (InputStream in = conn.getInputStream()) {
                    String json = new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
                    JsonElement root = JsonParser.parseString(json);
                    JsonArray arr = root.isJsonArray() ? root.getAsJsonArray() : root.getAsJsonObject().getAsJsonArray("tracks");
                    if (arr == null) throw new IllegalStateException("JSON precisa conter uma lista 'tracks'");
                    List<CatalogTrack> result = new ArrayList<>();
                    for (JsonElement el : arr) {
                        if (!el.isJsonObject()) continue;
                        JsonObject obj = el.getAsJsonObject();
                        CatalogTrack t = new CatalogTrack();
                        t.id = jsonString(obj, "id"); t.title = jsonString(obj, "title");
                        t.artist = jsonString(obj, "artist"); t.audioUrl = jsonString(obj, "audioUrl");
                        t.license = jsonString(obj, "license");
                        t.downloadable = obj.has("downloadable") && obj.get("downloadable").isJsonPrimitive()
                                && obj.get("downloadable").getAsBoolean();
                        t.durationSeconds = obj.has("durationSeconds") && obj.get("durationSeconds").isJsonPrimitive()
                                ? obj.get("durationSeconds").getAsDouble() : 0;
                        if (t.id == null || t.id.isBlank() || t.title == null || t.artist == null || t.audioUrl == null) continue;
                        if (!t.audioUrl.startsWith("https://")) continue;
                        result.add(t);
                    }
                    return result;
                }
            } catch (Exception ex) { throw new RuntimeException(ex.getMessage() == null ? "Falha ao acessar o catálogo" : ex.getMessage(), ex); }
            finally { if (conn != null) conn.disconnect(); }
        }).whenComplete((result, error) -> Platform.runLater(() -> {
            catalogLoading = false;
            if (error != null) { toast("Erro no catálogo: " + rootMessage(error)); buildMain(false); }
            else { catalogTracks.clear(); catalogTracks.addAll(result); buildMain(false); toast(catalogTracks.size() + " músicas no catálogo"); }
        }));
    }

    String jsonString(JsonObject obj, String key) {
        return obj.has(key) && !obj.get(key).isJsonNull() ? obj.get(key).getAsString() : null;
    }

    String rootMessage(Throwable e) {
        Throwable x = e; while (x.getCause() != null) x = x.getCause();
        return x.getMessage() == null ? "falha de conexão" : x.getMessage();
    }

    void downloadTrack(CatalogTrack t) {
        if (t == null || !t.downloadable || t.license == null || t.license.isBlank()) {
            toast("Esta faixa não está marcada como disponível para download autorizado"); return;
        }
        if (downloadedFiles.containsKey(t.id)) { toast("Essa música já está baixada"); return; }
        toast("Baixando: " + t.title);
        CompletableFuture.supplyAsync(() -> {
            HttpURLConnection conn = null;
            try {
                String safeId = t.id.replaceAll("[^A-Za-z0-9_-]", "_");
                if (safeId.isBlank()) throw new IllegalArgumentException("ID de música inválido");
                conn = (HttpURLConnection) new URL(t.audioUrl).openConnection();
                conn.setConnectTimeout(15000); conn.setReadTimeout(30000); conn.setInstanceFollowRedirects(false);
                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) throw new IllegalStateException("Download falhou (HTTP " + code + ")");
                String path = new URL(t.audioUrl).getPath();
                String ext = path.matches("(?i).*\\.(mp3|wav|m4a|aac|aif|aiff|ogg|flac)$") ? path.substring(path.lastIndexOf('.')) : ".mp3";
                File target = new File(downloadsDir, safeId + ext);
                File temp = new File(downloadsDir, safeId + ".part");
                long total = 0;
                try (InputStream in = conn.getInputStream(); OutputStream out = Files.newOutputStream(temp.toPath())) {
                    byte[] buf = new byte[32768]; int n;
                    while ((n = in.read(buf)) != -1) { total += n; if (total > 300L * 1024 * 1024) throw new IllegalStateException("Arquivo excede o limite de 300 MB"); out.write(buf, 0, n); }
                }
                if (total == 0) throw new IllegalStateException("O servidor enviou um arquivo vazio");
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
                Properties idx = new Properties(); File index = new File(appDir, "downloads.properties");
                if (index.isFile()) try (InputStream in = Files.newInputStream(index.toPath())) { idx.load(in); }
                String k = "track." + t.id + ".";
                idx.setProperty(k + "file", target.getName()); idx.setProperty(k + "title", t.title);
                idx.setProperty(k + "artist", t.artist); idx.setProperty(k + "license", t.license);
                idx.setProperty(k + "duration", Double.toString(t.durationSeconds));
                try (OutputStream out = Files.newOutputStream(index.toPath())) { idx.store(out, "Biblioteca offline do iSpotifai"); }
                return target;
            } catch (Exception ex) { throw new RuntimeException(ex.getMessage() == null ? "falha no download" : ex.getMessage(), ex); }
            finally { if (conn != null) conn.disconnect(); }
        }).whenComplete((file, error) -> Platform.runLater(() -> {
            if (error != null) { toast("Erro no download: " + rootMessage(error)); return; }
            downloadedFiles.put(t.id, file); downloadedTracks.put(t.id, t);
            Song s = new Song(); s.id = nid++; s.title = t.title; s.artist = t.artist; s.uri = file.toURI().toString(); s.dur = t.durationSeconds;
            songs.add(s); catalogTracks.removeIf(x -> x.id.equals(t.id)); catalogTracks.add(t);
            refreshAll(false); toast("Música salva para ouvir offline");
        }));
    }

    void removeDownload(String id) {
        File f = downloadedFiles.get(id);
        if (f == null) return;
        Song playing = songs.stream().filter(s -> s.uri.equals(f.toURI().toString())).findFirst().orElse(null);
        if (playing == cur) { if (mp != null) { mp.stop(); mp.dispose(); mp = null; } cur = null; }
        songs.removeIf(s -> s.uri.equals(f.toURI().toString()));
        liked.songs.removeIf(s -> s.uri.equals(f.toURI().toString()));
        for (Pl p : pls) p.songs.removeIf(s -> s.uri.equals(f.toURI().toString()));
        try { Files.deleteIfExists(f.toPath()); } catch (Exception ignored) { }
        downloadedFiles.remove(id); downloadedTracks.remove(id);
        try {
            Properties idx = new Properties(); File index = new File(appDir, "downloads.properties");
            if (index.isFile()) try (InputStream in = Files.newInputStream(index.toPath())) { idx.load(in); }
            String prefix = "track." + id + ".";
            for (String key : new ArrayList<>(idx.stringPropertyNames())) if (key.startsWith(prefix)) idx.remove(key);
            try (OutputStream out = Files.newOutputStream(index.toPath())) { idx.store(out, "Biblioteca offline do iSpotifai"); }
        } catch (Exception ignored) { }
        refreshAll(false); toast("Download removido");
    }

    void catalogView(VBox c) {
        HBox head = new HBox(12, lbl("Catálogo", 28, true, "white"), spacer(), pill("Configurar servidor", true, this::configureCatalog), pill("Atualizar", false, this::loadCatalog));
        head.setAlignment(Pos.CENTER_LEFT); head.setPadding(new Insets(8, 0, 12, 0)); c.getChildren().add(head);
        c.getChildren().add(lbl("Músicas disponibilizadas pelo seu servidor", 14, false, "#b3b3b3"));
        if (catalogUrl.isBlank()) { c.getChildren().add(cta("Conecte seu catálogo", "Informe a URL HTTPS do arquivo JSON hospedado no seu servidor.", "Configurar servidor", this::configureCatalog)); return; }
        if (catalogLoading) { c.getChildren().add(lbl("Carregando músicas...", 16, false, "#b3b3b3")); return; }
        if (catalogTracks.isEmpty()) { c.getChildren().add(cta("Nenhuma música carregada", "Confira a conexão e o formato JSON do catálogo.", "Tentar novamente", this::loadCatalog)); return; }
        for (CatalogTrack t : catalogTracks) {
            HBox row = new HBox(12); row.setAlignment(Pos.CENTER_LEFT); row.setPadding(new Insets(10)); row.getStyleClass().add("item");
            VBox meta = new VBox(4, lbl(t.title, 16, true, "white"), lbl(t.artist + (t.license == null || t.license.isBlank() ? "" : " • " + t.license), 13, false, "#b3b3b3"));
            HBox.setHgrow(meta, Priority.ALWAYS); row.getChildren().addAll(cover(48, false), meta);
            if (downloadedFiles.containsKey(t.id)) row.getChildren().add(pill("Baixada", true, () -> go(V.DOWNLOADS)));
            else row.getChildren().add(pill(t.downloadable && t.license != null && !t.license.isBlank() ? "Baixar" : "Indisponível", false, () -> downloadTrack(t)));
            Button playBtn = ib(PLAY, 18, () -> { File f = downloadedFiles.get(t.id); if (f != null) songs.stream().filter(s -> s.uri.equals(f.toURI().toString())).findFirst().ifPresent(s -> play(s, songs)); else toast("Baixe a música para reproduzi-la offline"); });
            row.getChildren().add(playBtn); c.getChildren().add(row);
        }
    }

    void downloadsView(VBox c) {
        HBox head = new HBox(12, lbl("Músicas baixadas", 28, true, "white"), spacer(), pill("Abrir catálogo", false, () -> { if (catalogTracks.isEmpty()) loadCatalog(); else go(V.CATALOG); }));
        head.setAlignment(Pos.CENTER_LEFT); c.getChildren().add(head);
        c.getChildren().add(lbl("Disponíveis sem conexão com a internet", 14, false, "#b3b3b3"));
        if (downloadedFiles.isEmpty()) { c.getChildren().add(cta("Ainda não há downloads", "Abra o catálogo e baixe músicas autorizadas para ouvir offline.", "Abrir catálogo", () -> { if (catalogTracks.isEmpty()) loadCatalog(); else go(V.CATALOG); })); return; }
        for (String id : new ArrayList<>(downloadedFiles.keySet())) {
            File f = downloadedFiles.get(id); CatalogTrack t = downloadedTracks.get(id);
            Song song = songs.stream().filter(s -> s.uri.equals(f.toURI().toString())).findFirst().orElse(null);
            if (song == null) continue;
            HBox row = new HBox(12); row.setAlignment(Pos.CENTER_LEFT); row.setPadding(new Insets(10)); row.getStyleClass().add("item");
            VBox meta = new VBox(4, lbl(song.title, 16, true, "white"), lbl(song.artist + " • Offline", 13, false, "#b3b3b3")); HBox.setHgrow(meta, Priority.ALWAYS);
            row.getChildren().addAll(cover(48, false), meta, ib(PLAY, 18, () -> play(song, songs)), ib(XX, 18, () -> removeDownload(id)));
            c.getChildren().add(row);
        }
    }

    // ---------- ações ----------
    void addFiles(Pl target) {
        FileChooser fc = new FileChooser();
        fc.setTitle("Adicionar músicas");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Áudio", "*.mp3", "*.wav", "*.m4a", "*.aac", "*.aif", "*.aiff"));
        List<File> files;
        if (MOBILE) {
            Set<String> have = songs.stream().map(x -> x.uri).collect(Collectors.toSet());
            files = androidMusic().stream().filter(f -> !have.contains(f.toURI().toString())).collect(Collectors.toList());
            if (files.isEmpty()) { toast("Nenhuma música nova na pasta Música do celular"); return; }
        } else files = fc.showOpenMultipleDialog(stage);
        if (files == null || files.isEmpty()) return;
        for (File f : files) {
            String n = f.getName().replaceAll("\\.[^.]+$", "").replace('_', ' ').trim(), a = "Artista desconhecido";
            int i = n.indexOf(" - ");
            if (i > 0) { a = n.substring(0, i).trim(); n = n.substring(i + 3).trim(); }
            Song s = new Song();
            s.id = nid++; s.title = n; s.artist = a; s.uri = f.toURI().toString();
            songs.add(s);
            if (target != null) target.songs.add(s);
            try {
                MediaPlayer p = new MediaPlayer(new Media(s.uri));
                probes.add(p);
                p.setOnReady(() -> { s.dur = p.getTotalDuration().toSeconds(); p.dispose(); probes.remove(p); refreshAll(true); });
                p.setOnError(() -> { p.dispose(); probes.remove(p); });
            } catch (Exception ex) { /* formato não suportado: segue sem duração */ }
        }
        toast(files.size() + (files.size() > 1 ? " músicas adicionadas" : " música adicionada"));
        refreshAll(true);
    }
    /** No Android não existe seletor de arquivos: lê os áudios da pasta Música do celular. */
    List<File> androidMusic() {
        List<File> out = new ArrayList<>();
        File dir = null;
        try {
            Optional<StorageService> st = StorageService.create();
            if (st.isPresent()) dir = st.get().getPublicStorage("Music").orElse(null);
        } catch (Throwable t) { /* usa o caminho padrão */ }
        if (dir == null) dir = new File("/storage/emulated/0/Music");
        collect(dir, out, 0);
        return out;
    }
    void collect(File d, List<File> out, int depth) {
        File[] fs = d.listFiles();
        if (fs == null || depth > 3) return;
        for (File f : fs) {
            if (f.isDirectory()) collect(f, out, depth + 1);
            else if (f.getName().toLowerCase().matches(".*\\.(mp3|wav|m4a|aac|aif|aiff)$")) out.add(f);
        }
    }

    void newPl(Song first) {
        ask("Criar playlist", "Minha playlist nº " + (pls.size() + 1), n -> {
            Pl p = new Pl(n);
            if (first != null) p.songs.add(first);
            pls.add(p);
            openPl(p);
        });
    }
    void openPl(Pl p) { view = V.PL; arg = p; refreshAll(false); }
    void go(V v) { view = v; refreshAll(false); }
    void toggleLike(Song s) {
        if (!liked.songs.remove(s)) liked.songs.add(s);
        refreshAll(true);
    }
    void removeSong(Song s) {
        songs.remove(s); liked.songs.remove(s);
        for (Pl p : pls) p.songs.remove(s);
        if (cur == s) { if (mp != null) { mp.stop(); mp.dispose(); mp = null; } cur = null; }
        refreshAll(true);
    }
    void play(Song s, List<Song> q) {
        if (s == cur && mp != null) { toggle(); return; }
        if (mp != null) { mp.stop(); mp.dispose(); mp = null; }
        cur = s;
        queue = new ArrayList<>(q.isEmpty() ? songs : q);
        final MediaPlayer p;
        try { p = new MediaPlayer(new Media(s.uri)); }
        catch (Exception e) { toast("Não foi possível tocar este arquivo"); cur = null; refreshAll(true); return; }
        mp = p;
        p.setVolume(vol.getValue());
        seek.setMax(Math.max(1, s.dur)); seek.setValue(0);
        p.setOnReady(() -> { s.dur = p.getTotalDuration().toSeconds(); seek.setMax(Math.max(1, s.dur)); durL.setText(fmt(s.dur)); });
        p.currentTimeProperty().addListener((o, a, b) -> {
            if (!seekDrag) seek.setValue(b.toSeconds());
            curL.setText(fmt(b.toSeconds()));
        });
        p.statusProperty().addListener((o, a, b) -> updatePp());
        p.setOnEndOfMedia(() -> { if (repeat == 2) { p.seek(Duration.ZERO); p.play(); } else step(1, true); });
        p.setOnError(() -> toast("Formato de áudio não suportado"));
        p.play();
        refreshAll(true);
    }
    void toggle() {
        if (mp == null) {
            if (songs.isEmpty()) toast("Adicione músicas para tocar"); else play(songs.get(0), songs);
            return;
        }
        if (mp.getStatus() == MediaPlayer.Status.PLAYING) mp.pause(); else mp.play();
    }
    void playPl(Pl p) {
        if (p.songs.isEmpty()) { toast("Essa playlist está vazia"); return; }
        cur = null;
        play(p.songs.get(0), p.songs);
    }
    void step(int d, boolean auto) {
        List<Song> q = queue.stream().filter(songs::contains).collect(Collectors.toList());
        if (q.isEmpty() || cur == null) return;
        int i = q.indexOf(cur), n;
        if (shuffle && q.size() > 1) { do { n = rnd.nextInt(q.size()); } while (n == i); }
        else {
            n = i + d;
            if (n >= q.size() || n < 0) {
                if (auto && repeat == 0) { if (mp != null) mp.stop(); updatePp(); return; }
                n = (n + q.size()) % q.size();
            }
        }
        Song nx = q.get(n);
        cur = null;
        play(nx, q);
    }
    void updatePp() {
        boolean pl = mp != null && mp.getStatus() == MediaPlayer.Status.PLAYING;
        ppIcon.setStyle("-fx-shape:\"" + (pl ? PAUSE : PLAY) + "\";");
    }
    void more(Node anchor, Song s, Pl ctx) {
        ContextMenu cm = new ContextMenu();
        for (Pl p : pls) {
            MenuItem mi = new MenuItem("Adicionar a: " + p.name);
            mi.setOnAction(e -> { if (!p.songs.contains(s)) p.songs.add(s); toast("Adicionada a " + p.name); refreshAll(true); });
            cm.getItems().add(mi);
        }
        MenuItem np = new MenuItem("Nova playlist com esta música");
        np.setOnAction(e -> newPl(s));
        cm.getItems().add(np);
        if (ctx != null) {
            MenuItem rm = new MenuItem(ctx == liked ? "Remover das curtidas" : "Remover desta playlist");
            rm.setOnAction(e -> { ctx.songs.remove(s); refreshAll(true); });
            cm.getItems().add(rm);
        }
        MenuItem del = new MenuItem("Remover da biblioteca");
        del.setOnAction(e -> removeSong(s));
        cm.getItems().add(del);
        cm.show(anchor, Side.BOTTOM, 0, 0);
    }

    // ---------- construção da janela ----------
    @Override
    public void start(Stage st) {
        stage = st;
        initDownloadStorage();
        css = getClass().getResource("/style.css").toExternalForm();
        BorderPane root = new BorderPane();
        root.getStyleClass().add("app");
        root.setTop(topBar());

        mainScroll = new ScrollPane();
        mainScroll.getStyleClass().add("main");
        mainScroll.setFitToWidth(true);
        mainScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        rp = new VBox();
        rp.getStyleClass().add("panel");
        rp.setPadding(new Insets(16));
        rp.setPrefWidth(320); rp.setMinWidth(320); rp.setMaxWidth(320);
        rp.setVisible(false); rp.setManaged(false);

        HBox mid = MOBILE ? new HBox(8, mainScroll) : new HBox(8, libPanel(), mainScroll, rp);
        HBox.setHgrow(mainScroll, Priority.ALWAYS);
        mid.setPadding(new Insets(0, 8, 0, 8));
        root.setCenter(mid);
        root.setBottom(playerBar());

        toastL.getStyleClass().add("toast");
        toastL.setStyle("-fx-font-weight:bold;-fx-text-fill:black;");
        toastL.setVisible(false);
        toastL.setMouseTransparent(true);
        toastT.setOnFinished(e -> toastL.setVisible(false));
        StackPane stack = new StackPane(root, toastL);
        StackPane.setAlignment(toastL, Pos.BOTTOM_CENTER);
        StackPane.setMargin(toastL, new Insets(0, 0, 96, 0));

        Scene sc = new Scene(stack, 1280, 780);
        sc.getStylesheets().add(css);
        sc.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.SPACE && !(sc.getFocusOwner() instanceof TextInputControl)) { toggle(); e.consume(); }
        });
        st.setTitle("iSpotifai");
        if (!MOBILE) { st.setMinWidth(900); st.setMinHeight(560); }
        st.setScene(sc);
        st.show();
        refreshAll(false);
    }

    Node topBar() {
        StackPane logo = new StackPane();
        Region circle = new Region();
        circle.setStyle("-fx-background-color:" + PURPLE + ";-fx-background-radius:100;");
        circle.setMinSize(32, 32); circle.setMaxSize(32, 32);
        SVGPath arcs = new SVGPath();
        arcs.setContent("M5.5 9c4.5-1.3 9.5-.9 13 1.2M6.3 12.6c3.7-1 7.6-.7 10.6 1M7 16c3-.8 6-.5 8.4.9");
        arcs.setFill(Color.TRANSPARENT); arcs.setStroke(Color.BLACK); arcs.setStrokeWidth(1.7);
        arcs.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        arcs.setScaleX(32 / 24.0); arcs.setScaleY(32 / 24.0);
        logo.getChildren().addAll(circle, new Group(arcs));
        logo.setPadding(new Insets(0, 0, 0, 8));
        logo.setMinWidth(40);

        Button home = new Button();
        home.setGraphic(ic(HOME, 24));
        home.getStyleClass().add("hb");
        home.setFocusTraversable(false);
        home.setOnAction(e -> { query = ""; searchF.setText(""); go(V.HOME); });

        searchF = new TextField();
        searchF.setPromptText("O que você quer ouvir?");
        searchF.getStyleClass().add("search-field");
        HBox.setHgrow(searchF, Priority.ALWAYS);
        searchF.textProperty().addListener((o, a, b) -> {
            if (b.equals(query)) return;
            query = b;
            if (view != V.SEARCH) { view = V.SEARCH; refreshAll(false); } else buildMain(false);
        });
        searchF.setOnMouseClicked(e -> { if (view != V.SEARCH) go(V.SEARCH); });
        Button browse = ib(BROWSE, 22, () -> { query = ""; searchF.setText(""); go(V.SEARCH); });
        HBox sb = new HBox(10, ic(SEARCH, 22), searchF, browse);
        sb.setAlignment(Pos.CENTER_LEFT);
        sb.getStyleClass().add("search-box");
        sb.setPrefHeight(48); sb.setMinHeight(48); if (!MOBILE) { sb.setMaxWidth(474); sb.setPrefWidth(474); }
        HBox center = new HBox(8, home, sb);
        HBox.setHgrow(sb, Priority.ALWAYS);
        center.setAlignment(Pos.CENTER);

        Button premium = pill("Explorar o Premium", false, () -> toast("Recurso de demonstração"));
        Button inst = new Button("Instalar app", ic(DL, 18));
        inst.getStyleClass().add("ghost"); inst.setFocusTraversable(false);
        Button bell = ib(BELL, 20, () -> toast("Sem novidades por enquanto"));
        Button fr = ib(FR, 20, () -> toast("Atividade de amigos indisponível"));
        Label av = lbl("V", 14, true, "black");
        StackPane avatar = new StackPane(av);
        avatar.getStyleClass().add("avatar");
        avatar.setMinSize(32, 32); avatar.setMaxSize(32, 32);
        StackPane avWrap = new StackPane(avatar);
        avWrap.setStyle("-fx-background-color:#1f1f1f;-fx-background-radius:100;");
        avWrap.setMinSize(48, 48); avWrap.setMaxSize(48, 48);
        HBox right = new HBox(8, premium, inst, bell, fr, avWrap);
        right.setAlignment(Pos.CENTER_RIGHT);

        BorderPane bp = new BorderPane();
        bp.setLeft(logo); bp.setCenter(center); if (!MOBILE) bp.setRight(right);
        BorderPane.setAlignment(logo, Pos.CENTER_LEFT);
        bp.setPadding(new Insets(8));
        bp.setPrefHeight(64); bp.setMinHeight(64);
        return bp;
    }

    Node libPanel() {
        Label title = lbl("Sua Biblioteca", 16, true, "#b3b3b3");
        HBox t = new HBox(12, ic(LIB, 24), title);
        t.setAlignment(Pos.CENTER_LEFT);
        Button plus = ib(PLUS, 16, () -> {
            ContextMenu cm = new ContextMenu();
            MenuItem a = new MenuItem("Criar playlist"); a.setOnAction(e -> newPl(null));
            MenuItem b = new MenuItem("Adicionar músicas"); b.setOnAction(e -> addFiles(null));
            cm.getItems().addAll(a, b);
            cm.show(stage, javafx.stage.Screen.getPrimary().getVisualBounds().getMinX() + 250, 140);
        });
        plus.getStyleClass().add("round");
        Button arrow = ib(ARROW, 16, () -> {});
        arrow.getStyleClass().add("round");
        HBox head = new HBox(4, t, spacer(), plus, arrow);
        head.setAlignment(Pos.CENTER_LEFT);
        head.setPadding(new Insets(12, 12, 8, 16));

        chipPl = new Button("Playlists"); chipSg = new Button("Músicas");
        for (Button c : new Button[]{chipPl, chipSg}) { c.getStyleClass().add("chip"); c.setFocusTraversable(false); }
        chipPl.setOnAction(e -> { libSongs = false; buildLib(); });
        chipSg.setOnAction(e -> { libSongs = true; buildLib(); });
        HBox chips = new HBox(8, chipPl, chipSg);
        chips.setPadding(new Insets(4, 16, 8, 16));
        Button catalogNav = new Button("Catálogo"); catalogNav.getStyleClass().add("chip"); catalogNav.setMaxWidth(Double.MAX_VALUE);
        Button downloadsNav = new Button("Baixadas"); downloadsNav.getStyleClass().add("chip"); downloadsNav.setMaxWidth(Double.MAX_VALUE);
        catalogNav.setOnAction(e -> { if (catalogTracks.isEmpty()) loadCatalog(); else go(V.CATALOG); });
        downloadsNav.setOnAction(e -> go(V.DOWNLOADS));
        HBox downloadNav = new HBox(8, catalogNav, downloadsNav); downloadNav.setPadding(new Insets(0, 16, 8, 16));

        Button ls = ib(SEARCH, 16, () -> searchF.requestFocus());
        Label rc = lbl("Recentes", 14, false, "#b3b3b3");
        HBox sub = new HBox(6, ls, spacer(), rc, ic(MENU, 16));
        sub.setAlignment(Pos.CENTER_LEFT);
        sub.setPadding(new Insets(4, 16, 8, 12));

        libList = new VBox();
        libList.setPadding(new Insets(0, 8, 8, 8));
        ScrollPane sp = new ScrollPane(libList);
        sp.setFitToWidth(true);
        sp.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        VBox.setVgrow(sp, Priority.ALWAYS);
        VBox box = new VBox(head, chips, downloadNav, sub, sp);
        box.getStyleClass().add("panel");
        box.setPrefWidth(300); box.setMinWidth(300); box.setMaxWidth(300);
        return box;
    }

    Node playerBar() {
        npCover = cover(56, false);
        heartBtn = new Button();
        heartBtn.setGraphic(heartHolder);
        heartBtn.getStyleClass().add("ib");
        heartBtn.setOnAction(e -> { if (cur != null) toggleLike(cur); });
        VBox txt = new VBox(2, npTitle, npArtist);
        txt.setAlignment(Pos.CENTER_LEFT);
        npBox = new HBox(14, npCover, txt, heartBtn);
        npBox.setAlignment(Pos.CENTER_LEFT);
        npBox.setVisible(false);

        shufBtn = ib(SHUF, 20, () -> { shuffle = !shuffle; on(shufBtn, shuffle); });
        Button prev = ib(PREV, 20, () -> { if (mp != null && mp.getCurrentTime().toSeconds() > 3) mp.seek(Duration.ZERO); else step(-1, false); });
        ppIcon = ic(PLAY, 16);
        ppBtn = new Button();
        ppBtn.setGraphic(ppIcon);
        ppBtn.getStyleClass().add("pp");
        ppBtn.setMinSize(32, 32); ppBtn.setPrefSize(32, 32); ppBtn.setMaxSize(32, 32);
        ppBtn.setFocusTraversable(false);
        ppBtn.setOnAction(e -> toggle());
        Button next = ib(NEXT, 20, () -> step(1, false));
        repBtn = ib(REP, 20, () -> {
            repeat = (repeat + 1) % 3;
            on(repBtn, repeat > 0);
            toast(new String[]{"Repetição desativada", "Repetir todas", "Repetir uma"}[repeat]);
        });
        HBox ctrl = new HBox(20, shufBtn, prev, ppBtn, next, repBtn);
        ctrl.setAlignment(Pos.CENTER);

        fill(seek); fill(vol);
        seek.setOnMousePressed(e -> seekDrag = true);
        seek.setOnMouseReleased(e -> { seekDrag = false; if (mp != null) mp.seek(Duration.seconds(seek.getValue())); });
        HBox.setHgrow(seek, Priority.ALWAYS);
        curL.setMinWidth(40); curL.setAlignment(Pos.CENTER);
        durL.setMinWidth(40); durL.setAlignment(Pos.CENTER);
        HBox prog = new HBox(8, curL, seek, durL);
        prog.setAlignment(Pos.CENTER);
        prog.setMaxWidth(722);
        VBox center = new VBox(8, ctrl, prog);
        center.setAlignment(Pos.CENTER);

        npvBtn = ib(NPV, 18, () -> rpMode("np"));
        qbBtn = ib(QUEUE, 18, () -> rpMode("q"));
        Button lyr = ib(MIC, 18, () -> toast("Letras não disponíveis para esta música"));
        Button dev = ib(DEV, 18, () -> toast("Nenhum dispositivo encontrado"));
        muteBtn = ib(VOL, 18, () -> {
            if (vol.getValue() > 0) { lastVol = vol.getValue(); vol.setValue(0); } else vol.setValue(lastVol > 0 ? lastVol : .7);
        });
        vol.valueProperty().addListener((o, a, b) -> {
            if (mp != null) mp.setVolume(b.doubleValue());
            muteBtn.setGraphic(ic(b.doubleValue() > 0 ? VOL : MUTE, 18));
        });
        vol.setPrefWidth(93); vol.setMaxWidth(93);
        Button fs = ib(FS, 18, () -> stage.setFullScreen(!stage.isFullScreen()));
        HBox rt = new HBox(8, npvBtn, lyr, qbBtn, dev, muteBtn, vol, fs);
        rt.setAlignment(Pos.CENTER_RIGHT);

        if (MOBILE) {
            npTitle.setMaxWidth(170); npArtist.setMaxWidth(170);
            HBox row = new HBox(12, npBox, spacer(), prev, ppBtn, next);
            row.setAlignment(Pos.CENTER_LEFT); row.setPadding(new Insets(8, 12, 4, 12));
            prog.setMaxWidth(Double.MAX_VALUE); prog.setPadding(new Insets(0, 12, 4, 12));
            HBox tabs = new HBox();
            String[] tn = {"Início", "Buscar", "Biblioteca"};
            for (int i = 0; i < 3; i++) {
                final int k = i;
                Button b = new Button(tn[i]);
                b.getStyleClass().add("ghost"); b.setMaxWidth(Double.MAX_VALUE); b.setFocusTraversable(false);
                HBox.setHgrow(b, Priority.ALWAYS);
                b.setOnAction(e -> go(k == 0 ? V.HOME : k == 1 ? V.SEARCH : V.LIB));
                tabs.getChildren().add(b);
            }
            tabs.setPadding(new Insets(4, 0, 12, 0));
            VBox mb = new VBox(row, prog, tabs);
            mb.setStyle("-fx-background-color:#2a1a40;");
            return mb;
        }
        GridPane g = new GridPane();
        ColumnConstraints c1 = new ColumnConstraints(); c1.setPercentWidth(30);
        ColumnConstraints c2 = new ColumnConstraints(); c2.setPercentWidth(40); c2.setHalignment(javafx.geometry.HPos.CENTER);
        ColumnConstraints c3 = new ColumnConstraints(); c3.setPercentWidth(30); c3.setHalignment(javafx.geometry.HPos.RIGHT);
        g.getColumnConstraints().addAll(c1, c2, c3);
        g.add(npBox, 0, 0); g.add(center, 1, 0); g.add(rt, 2, 0);
        RowConstraints rc = new RowConstraints(72); rc.setValignment(VPos.CENTER);
        g.getRowConstraints().add(rc);
        g.setPadding(new Insets(0, 8, 0, 8));
        g.setStyle("-fx-background-color:black;");
        return g;
    }

    void rpMode(String m) {
        boolean same = rpOpen && rpMode.equals(m);
        rpMode = m;
        rpOpen = !same;
        rp.setVisible(rpOpen); rp.setManaged(rpOpen);
        on(npvBtn, rpOpen && m.equals("np")); on(qbBtn, rpOpen && m.equals("q"));
        buildRp();
    }

    // ---------- atualização ----------
    void refreshAll(boolean keep) {
        buildLib();
        buildMain(keep);
        refreshPlayer();
        buildRp();
    }

    void refreshPlayer() {
        npBox.setVisible(cur != null);
        if (cur != null) {
            npTitle.setText(cur.title); npArtist.setText(cur.artist);
            heartHolder.getChildren().setAll(heart(liked.songs.contains(cur), 18));
            durL.setText(fmt(cur.dur));
        } else { seek.setValue(0); curL.setText("0:00"); durL.setText("0:00"); }
        on(shufBtn, shuffle); on(repBtn, repeat > 0);
        updatePp();
    }

    void buildRp() {
        rp.getChildren().clear();
        Button x = ib(XX, 16, () -> rpMode(rpMode));
        HBox head = new HBox(lbl(rpMode.equals("q") ? "Fila" : "Tocando agora", 16, true, "white"), spacer(), x);
        head.setAlignment(Pos.CENTER_LEFT);
        head.setPadding(new Insets(0, 0, 16, 0));
        rp.getChildren().add(head);
        List<Song> q = queue.stream().filter(songs::contains).collect(Collectors.toList());
        int i = cur == null ? -1 : q.indexOf(cur);
        List<Song> next = i >= 0 ? q.subList(i + 1, Math.min(q.size(), i + 11)) : new ArrayList<>();
        if (cur == null) {
            rp.getChildren().add(lbl(rpMode.equals("q") ? "Toque uma música para ver a fila." : "Nada tocando no momento.", 14, false, "#b3b3b3"));
            return;
        }
        if (rpMode.equals("q")) {
            rp.getChildren().addAll(lbl("Tocando agora", 16, true, "white"), songItem(cur));
            if (!next.isEmpty()) {
                Label h = lbl("A seguir", 16, true, "white");
                h.setPadding(new Insets(20, 0, 0, 0));
                rp.getChildren().add(h);
                for (Song s : next) rp.getChildren().add(songItem(s));
            }
        } else {
            StackPane c = cover(288, false);
            Label t = lbl(cur.title, 24, true, "white"); t.setWrapText(true);
            Label a = lbl(cur.artist, 16, false, "#b3b3b3");
            VBox.setMargin(t, new Insets(20, 0, 0, 0));
            rp.getChildren().addAll(c, t, a);
            if (!next.isEmpty()) {
                Label h = lbl("A seguir", 16, true, "white");
                h.setPadding(new Insets(28, 0, 8, 0));
                rp.getChildren().addAll(h, songItem(next.get(0)));
            }
        }
    }

    void buildLib() {
        if (libList == null) return;
        libList.getChildren().clear();
        on(chipPl, !libSongs); on(chipSg, libSongs);
        if (libSongs) {
            if (songs.isEmpty()) libList.getChildren().add(cta("Nenhuma música ainda", "Adicione arquivos de áudio do seu dispositivo.", "Adicionar músicas", () -> addFiles(null)));
            for (Song s : songs) libList.getChildren().add(songItem(s));
        } else {
            libList.getChildren().add(plItem(liked));
            for (Pl p : pls) libList.getChildren().add(plItem(p));
            if (pls.isEmpty()) libList.getChildren().add(cta("Crie sua primeira playlist", "É fácil, vamos te ajudar.", "Criar playlist", () -> newPl(null)));
        }
    }

    Node cta(String t, String p, String b, Runnable r) {
        Label pl = lbl(p, 14, false, "white"); pl.setWrapText(true);
        VBox v = new VBox(8, lbl(t, 16, true, "white"), pl, pill(b, false, r));
        v.setSpacing(12);
        v.getStyleClass().add("cta");
        VBox.setMargin(v, new Insets(8, 0, 0, 0));
        return v;
    }
    Node plItem(Pl p) {
        Label sub = lbl("Playlist • " + (p == liked ? p.songs.size() + " músicas" : "Você"), 14, false, "#b3b3b3");
        HBox sh = new HBox(4);
        if (p == liked) sh.getChildren().add(icc(PIN, 14, PURPLE));
        sh.getChildren().add(sub);
        sh.setAlignment(Pos.CENTER_LEFT);
        VBox v = new VBox(2, lbl(p.name, 16, false, p == arg && view == V.PL ? "#c084fc" : "white"), sh);
        v.setAlignment(Pos.CENTER_LEFT);
        HBox h = new HBox(12, cover(48, p == liked), v);
        h.setAlignment(Pos.CENTER_LEFT);
        h.getStyleClass().add("item");
        h.setOnMouseClicked(e -> openPl(p));
        return h;
    }
    Node songItem(Song s) {
        VBox v = new VBox(2, lbl(s.title, 16, false, s == cur ? "#c084fc" : "white"), lbl(s.artist, 14, false, "#b3b3b3"));
        v.setAlignment(Pos.CENTER_LEFT);
        HBox h = new HBox(12, cover(48, false), v);
        h.setAlignment(Pos.CENTER_LEFT);
        h.getStyleClass().add("item");
        h.setOnMouseClicked(e -> play(s, queue.contains(s) ? queue : songs));
        return h;
    }

    // ---------- área principal ----------
    void buildMain(boolean keep) {
        double sv = mainScroll.getVvalue();
        VBox c = new VBox();
        c.getStyleClass().add(view == V.HOME || view == V.PL ? "hero-content" : "plain-content");
        c.setPadding(new Insets(16, 24, 32, 24));
        c.minHeightProperty().bind(mainScroll.heightProperty().subtract(2));
        switch (view) {
            case HOME -> home(c);
            case SEARCH -> search(c);
            case LIB -> libView(c);
            case PL -> plView(c);
            case CATALOG -> catalogView(c);
            case DOWNLOADS -> downloadsView(c);
        }
        mainScroll.setContent(c);
        mainScroll.setVvalue(keep ? sv : 0);
    }

    void home(VBox c) {
        if (songs.isEmpty() && pls.isEmpty()) { c.getChildren().addAll(emptyBox(), footer()); return; }
        Button all = new Button("Tudo"), mus = new Button("Música");
        all.getStyleClass().addAll("chip", "chip-p", "on"); mus.getStyleClass().add("chip");
        all.setFocusTraversable(false); mus.setFocusTraversable(false);
        HBox chips = new HBox(8, all, mus);
        chips.setPadding(new Insets(0, 0, 16, 0));
        FlowPane q = new FlowPane(8, 8);
        List<Pl> qk = new ArrayList<>();
        qk.add(liked); qk.addAll(pls);
        for (Pl p : qk.subList(0, Math.min(8, qk.size()))) q.getChildren().add(quick(p));
        c.getChildren().addAll(chips, q);
        if (!songs.isEmpty()) c.getChildren().add(shelf("Suas músicas", songs.stream().map(this::songCard).collect(Collectors.toList())));
        if (!pls.isEmpty()) c.getChildren().add(shelf("Suas playlists", pls.stream().map(this::plCard).collect(Collectors.toList())));
        c.getChildren().add(footer());
    }

    Node emptyBox() {
        Label h = lbl("Sua coleção está vazia", 28, true, "white");
        Label p = lbl("Adicione músicas do seu dispositivo para começar a ouvir.", 16, false, "#b3b3b3");
        Button a = pill("Adicionar músicas", false, () -> addFiles(null));
        a.getStyleClass().add("pill-big");
        Button n = pill("Criar playlist", true, () -> newPl(null));
        HBox btns = new HBox(24, a, n);
        btns.setAlignment(Pos.CENTER);
        VBox v = new VBox(12, icc(NOTE, 56, "#b3b3b3"), h, p, btns);
        v.setAlignment(Pos.CENTER);
        v.setPadding(new Insets(56, 0, 0, 0));
        return v;
    }

    Node quick(Pl p) {
        Button g = goBtn(40, () -> playPl(p));
        g.setVisible(MOBILE);
        HBox h = new HBox(14, cover(48, p == liked), lbl(p.name, 15, true, "white"), spacer(), g);
        h.setAlignment(Pos.CENTER_LEFT);
        h.setPadding(new Insets(0, 4, 0, 0));
        h.getStyleClass().add("quick");
        h.setPrefSize(270, 48); h.setMinSize(270, 48); h.setMaxSize(270, 48);
        h.setOnMouseEntered(e -> g.setVisible(true));
        h.setOnMouseExited(e -> g.setVisible(MOBILE));
        h.setOnMouseClicked(e -> openPl(p));
        return h;
    }

    Node shelf(String t, List<Node> cards) {
        Button more = new Button("Mostrar tudo");
        more.getStyleClass().add("lnk");
        HBox head = new HBox(lbl(t, 24, true, "white"), spacer(), more);
        head.setAlignment(Pos.BASELINE_LEFT);
        head.setPadding(new Insets(28, 0, 4, 0));
        FlowPane fp = new FlowPane();
        fp.getChildren().addAll(cards);
        boolean[] open = {false};
        Runnable apply = () -> {
            for (int i = 0; i < cards.size(); i++) {
                boolean show = open[0] || i < 5;
                cards.get(i).setVisible(show); cards.get(i).setManaged(show);
            }
        };
        apply.run();
        more.setOnAction(e -> { open[0] = !open[0]; more.setText(open[0] ? "Mostrar menos" : "Mostrar tudo"); apply.run(); });
        return new VBox(head, fp);
    }

    Node card(boolean lk, String title, String sub, Runnable open, Runnable playR) {
        StackPane cv = cover(156, lk);
        Button g = goBtn(48, playR);
        g.setVisible(MOBILE);
        StackPane.setAlignment(g, Pos.BOTTOM_RIGHT);
        StackPane.setMargin(g, new Insets(8));
        cv.getChildren().add(g);
        Label t = lbl(title, 16, true, "white"); t.setMaxWidth(156);
        Label s = lbl(sub, 14, false, "#b3b3b3"); s.setMaxWidth(156);
        VBox.setMargin(t, new Insets(16, 0, 4, 0));
        VBox v = new VBox(cv, t, s);
        v.getStyleClass().add("card");
        v.setPadding(new Insets(12));
        v.setPrefWidth(180); v.setMinWidth(180); v.setMaxWidth(180);
        v.setOnMouseEntered(e -> g.setVisible(true));
        v.setOnMouseExited(e -> g.setVisible(MOBILE));
        v.setOnMouseClicked(e -> open.run());
        return v;
    }
    Node plCard(Pl p) { return card(p == liked, p.name, "Playlist • " + p.songs.size() + " músicas", () -> openPl(p), () -> playPl(p)); }
    Node songCard(Song s) { return card(false, s.title, s.artist, () -> play(s, songs), () -> play(s, songs)); }

    Node footer() {
        VBox e = col("Empresa", "Sobre", "Carreiras", "For the Record");
        VBox c = col("Comunidades", "Para artistas", "Desenvolvedores", "Publicidade", "Investidores", "Fornecedores");
        VBox u = col("Links úteis", "Suporte", "App Mobile Grátis");
        HBox soc = new HBox(16);
        for (String s : new String[]{"I", "X", "f"}) {
            StackPane p = new StackPane(lbl(s, 14, true, "white"));
            p.setStyle("-fx-background-color:#292929;-fx-background-radius:100;");
            p.setMinSize(40, 40); p.setMaxSize(40, 40);
            soc.getChildren().add(p);
        }
        HBox top = new HBox(56, e, c, u, spacer(), soc);
        FlowPane links = new FlowPane(24, 12);
        for (String s : new String[]{"Legal", "Centro de Privacidade", "Política de Privacidade", "Cookies", "Sobre anúncios", "Acessibilidade"})
            links.getChildren().add(lbl(s, 11, false, "#b3b3b3"));
        links.setPadding(new Insets(40, 0, 0, 0));
        VBox f = new VBox(top, links);
        f.setPadding(new Insets(64, 0, 0, 0));
        return f;
    }
    VBox col(String h, String... items) {
        VBox v = new VBox(12, lbl(h, 16, true, "white"));
        for (String s : items) v.getChildren().add(lbl(s, 16, false, "#b3b3b3"));
        return v;
    }

    void search(VBox c) {
        String q = query.trim().toLowerCase();
        if (q.isEmpty()) {
            FlowPane fp = new FlowPane(24, 24);
            for (int i = 0; i < CATS.length; i++) {
                String name = CATS[i];
                Label l = lbl(name, 24, true, "white");
                l.setWrapText(true); l.setMaxWidth(160);
                Region sq = icc(NOTE, 30, "#ffffff99");
                StackPane tile = new StackPane(l, sq);
                StackPane.setAlignment(l, Pos.TOP_LEFT);
                StackPane.setAlignment(sq, Pos.BOTTOM_RIGHT);
                StackPane.setMargin(sq, new Insets(0, 14, 14, 0));
                tile.setPadding(new Insets(16));
                tile.setStyle("-fx-background-color:" + CAT_COLORS[i] + ";");
                tile.getStyleClass().add("cat");
                tile.setPrefSize(190, 190); tile.setMinSize(190, 190); tile.setMaxSize(190, 190);
                tile.setOnMouseClicked(e -> searchF.setText(name));
                fp.getChildren().add(tile);
            }
            c.getChildren().addAll(lbl("Navegar por todas as seções", 24, true, "white"), fp, footer());
            ((Label) c.getChildren().get(0)).setPadding(new Insets(0, 0, 14, 0));
            return;
        }
        List<Song> ss = songs.stream().filter(s -> (s.title + " " + s.artist).toLowerCase().contains(q)).collect(Collectors.toList());
        List<Pl> pp = pls.stream().filter(p -> p.name.toLowerCase().contains(q)).collect(Collectors.toList());
        if (ss.isEmpty() && pp.isEmpty()) {
            VBox v = new VBox(8, lbl("Nenhum resultado para \"" + query + "\"", 24, true, "white"),
                    lbl("Confira a ortografia ou tente outras palavras.", 16, false, "#b3b3b3"));
            v.setAlignment(Pos.CENTER);
            v.setPadding(new Insets(56, 0, 0, 0));
            c.getChildren().add(v);
            return;
        }
        if (!ss.isEmpty()) { c.getChildren().addAll(lbl("Músicas", 24, true, "white"), rows(ss, null)); }
        if (!pp.isEmpty()) {
            FlowPane fp = new FlowPane();
            for (Pl p : pp) fp.getChildren().add(plCard(p));
            Label h = lbl("Playlists", 24, true, "white"); h.setPadding(new Insets(28, 0, 8, 0));
            c.getChildren().addAll(h, fp);
        }
    }

    void libView(VBox c) {
        FlowPane fp = new FlowPane();
        fp.getChildren().add(plCard(liked));
        for (Pl p : pls) fp.getChildren().add(plCard(p));
        HBox nav = new HBox(8, pill("Catálogo de músicas", false, () -> { if (catalogTracks.isEmpty()) loadCatalog(); else go(V.CATALOG); }), pill("Músicas baixadas", true, () -> go(V.DOWNLOADS)));
        nav.setPadding(new Insets(12, 0, 16, 0));
        c.getChildren().addAll(lbl("Sua Biblioteca", 24, true, "white"), nav, fp);
    }

    void plView(VBox c) {
        Pl p = arg == null ? liked : arg;
        double tot = p.songs.stream().mapToDouble(s -> s.dur).sum();
        Label title = lbl(p.name, 64, true, "white");
        title.setWrapText(true);
        Label av = lbl("V", 11, true, "black");
        StackPane avatar = new StackPane(av);
        avatar.getStyleClass().add("avatar");
        avatar.setMinSize(24, 24); avatar.setMaxSize(24, 24);
        String info = "• " + p.songs.size() + " músicas" + (tot > 0 ? ", " + Math.max(1, Math.round(tot / 60)) + " min" : "");
        HBox owner = new HBox(6, avatar, lbl("Você", 14, true, "white"), lbl(info, 14, false, "white"));
        owner.setAlignment(Pos.CENTER_LEFT);
        VBox meta = new VBox(6, lbl("Playlist", 14, true, "white"), title, owner);
        meta.setAlignment(Pos.BOTTOM_LEFT);
        HBox ph = new HBox(24, cover(232, p == liked), meta);
        ph.setAlignment(Pos.BOTTOM_LEFT);
        ph.setPadding(new Insets(40, 0, 24, 0));

        HBox acts = new HBox(28, goBtn(56, () -> playPl(p)));
        Button sh = ib(SHUF, 28, () -> { shuffle = !shuffle; on(shufBtn, shuffle); buildMain(true); });
        on(sh, shuffle);
        acts.getChildren().add(sh);
        if (p != liked) {
            Button dots = ib(DOTS, 28, () -> {
                ContextMenu cm = new ContextMenu();
                MenuItem r = new MenuItem("Renomear"); r.setOnAction(e -> ask("Renomear playlist", p.name, n -> { p.name = n; refreshAll(true); }));
                MenuItem d = new MenuItem("Excluir playlist"); d.setOnAction(e -> { pls.remove(p); arg = null; go(V.HOME); toast("Playlist excluída"); });
                cm.getItems().addAll(r, d);
                cm.show(stage, stage.getX() + 700, stage.getY() + 360);
            });
            acts.getChildren().addAll(ib(PLUS, 28, () -> addFiles(p)), dots);
        }
        acts.getChildren().addAll(spacer(), lbl("Lista", 14, false, "#b3b3b3"), ic(MENU, 16));
        acts.setAlignment(Pos.CENTER_LEFT);
        acts.setPadding(new Insets(8, 0, 24, 0));
        c.getChildren().addAll(ph, acts);
        if (p.songs.isEmpty()) {
            VBox v = new VBox(12, lbl(p == liked ? "Músicas que você curtir aparecerão aqui" : "Vamos incluir algo na sua playlist", 24, true, "white"));
            if (p != liked) v.getChildren().add(pill("Adicionar músicas", false, () -> addFiles(p)));
            v.setAlignment(Pos.CENTER);
            v.setPadding(new Insets(40, 0, 0, 0));
            c.getChildren().add(v);
        } else c.getChildren().add(rows(new ArrayList<>(p.songs), p));
    }

    // ---------- tabela de músicas ----------
    static void hideCols(GridPane g) {
        for (int k : new int[]{2, 3, 5}) g.getChildren().get(k).setVisible(false);
    }

    GridPane grid() {
        GridPane g = new GridPane();
        g.setHgap(MOBILE ? 8 : 16);
        double[] w = MOBILE ? new double[]{24, -1, 0, 0, 36, 0, 36} : new double[]{24, -1, 150, 110, 36, 56, 36};
        for (double x : w) {
            ColumnConstraints cc = new ColumnConstraints();
            if (x < 0) { cc.setHgrow(Priority.ALWAYS); cc.setMinWidth(120); }
            else { cc.setMinWidth(x); cc.setPrefWidth(x); cc.setMaxWidth(x); }
            g.getColumnConstraints().add(cc);
        }
        RowConstraints rc = new RowConstraints(); rc.setValignment(VPos.CENTER);
        g.getRowConstraints().add(rc);
        return g;
    }

    Node rows(List<Song> list, Pl ctx) {
        VBox v = new VBox();
        GridPane h = grid();
        h.getStyleClass().add("trh");
        h.setMinHeight(36); h.setPrefHeight(36);
        h.addRow(0, lbl("#", 13, false, "#b3b3b3"), lbl("Título", 13, false, "#b3b3b3"), lbl("Álbum", 13, false, "#b3b3b3"),
                lbl("Data de inclusão", 13, false, "#b3b3b3"), new Region(), icc(CLOCK, 16, "#b3b3b3"), new Region());
        if (MOBILE) hideCols(h);
        v.getChildren().add(h);
        VBox.setMargin(h, new Insets(0, 0, 8, 0));
        for (int i = 0; i < list.size(); i++) v.getChildren().add(row(i, list.get(i), ctx, list));
        return v;
    }

    Node row(int idx, Song s, Pl ctx, List<Song> list) {
        GridPane g = grid();
        g.getStyleClass().add("tr");
        g.setMinHeight(56); g.setPrefHeight(56);
        boolean isCur = s == cur;
        Label num = lbl(String.valueOf(idx + 1), 16, false, isCur ? "#c084fc" : "#b3b3b3");
        Region pi = icc(PLAY, 14, "white");
        pi.setVisible(false);
        StackPane ns = new StackPane(num, pi);
        VBox tv = new VBox(2, lbl(s.title, 16, false, isCur ? "#c084fc" : "white"), lbl(s.artist, 14, false, "#b3b3b3"));
        tv.setAlignment(Pos.CENTER_LEFT);
        HBox title = new HBox(14, cover(40, false), tv);
        title.setAlignment(Pos.CENTER_LEFT);
        String date = DateTimeFormatter.ofPattern("dd/MM/yyyy").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(s.added));
        boolean lk = liked.songs.contains(s);
        Button hb = new Button();
        hb.setGraphic(heart(lk, 18));
        hb.getStyleClass().add("ib");
        hb.setOpacity(lk || MOBILE ? 1 : 0);
        hb.setOnAction(e -> toggleLike(s));
        stop(hb);
        Button mo = ib(DOTS, 18, () -> {});
        mo.setOpacity(MOBILE ? 1 : 0);
        mo.setOnAction(e -> more(mo, s, ctx));
        stop(mo);
        g.addRow(0, ns, title, lbl("—", 14, false, "#b3b3b3"), lbl(date, 14, false, "#b3b3b3"), hb, lbl(fmt(s.dur), 14, false, "#b3b3b3"), mo);
        if (MOBILE) hideCols(g);
        g.setOnMouseEntered(e -> { num.setVisible(false); pi.setVisible(true); hb.setOpacity(1); mo.setOpacity(1); });
        g.setOnMouseExited(e -> { num.setVisible(true); pi.setVisible(false); hb.setOpacity(lk || MOBILE ? 1 : 0); mo.setOpacity(MOBILE ? 1 : 0); });
        g.setOnMouseClicked(e -> play(s, list));
        return g;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
